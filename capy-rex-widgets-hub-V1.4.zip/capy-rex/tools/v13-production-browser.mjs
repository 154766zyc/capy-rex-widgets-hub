import assert from 'node:assert/strict';
import {writeFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
const {chromium}=await import(process.env.PLAYWRIGHT_MODULE);
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH,headless:true,chromiumSandbox:true});
const report={browser:await browser.version(),site:'https://capy.fnzyc.top',errors:[]};
try{
 const ctx=await browser.newContext({viewport:{width:1440,height:1000},permissions:['clipboard-read','clipboard-write'],userAgent:'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36'});
 const p=await ctx.newPage();p.on('pageerror',e=>report.errors.push(e.message));
 await p.goto(report.site+'/user');await p.locator('#catalog .card').first().waitFor();assert.match(await p.title(),/V1.3/);
 report.catalogCount=await p.locator('#catalog .card').count();
 await p.locator('[data-platform="capy"]').click();assert.ok(await p.locator('#catalog .card').count()>0);
 const href=await p.locator('.install-link').first().getAttribute('href');const decoded=Buffer.from(new URL(href).searchParams.get('data'),'base64url').toString();assert.match(decoded,/^https:\/\/capy.fnzyc.top\/raw\/[a-f0-9-]+\.js$/);
 const domHref=await p.locator('.install-link').first().evaluate(e=>e.href);assert.equal(href,domHref);
 await p.locator('.install-link').first().click();await p.waitForFunction(()=>document.getElementById('message').textContent==='操作完成');assert.equal(await p.evaluate(()=>navigator.clipboard.readText()),decoded);report.windowsCopiesHTTPS=true;report.capyHrefUnchangedInDOM=true;
 await p.locator('#search').fill('芜湖');report.authorSearchMatches=await p.locator('#catalog .card').count();assert.ok(report.authorSearchMatches>0);
 await p.locator('#search').fill('不存在的测试查询v13');assert.equal(await p.locator('#catalog .card').count(),0);
 await p.locator('#clearSearch').click();assert.equal(await p.locator('#catalog .card').count(),report.catalogCount);
 await p.screenshot({path:'验证证据/V1.3/production-public-desktop.png',fullPage:true});
 await p.goto(report.site+'/checker');await p.fill('#code','var WidgetMetadata={title:"Online check",modules:[{title:"List",functionName:"list"}]};async function list(){return [];} while(true){};');await p.click('#check');await p.waitForFunction(()=>document.getElementById('result').textContent.includes('"ok": true'));report.onlineChecker=true;await p.screenshot({path:'验证证据/V1.3/production-checker.png',fullPage:true});
 await p.goto(report.site+'/admin');await p.locator('#login').waitFor({state:'visible'});await p.screenshot({path:'验证证据/V1.3/production-admin-login.png',fullPage:true});report.adminAuthRequired=true;
 await p.setViewportSize({width:390,height:844});await p.goto(report.site+'/user');await p.locator('#catalog .card').first().waitFor();assert.equal(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);await p.screenshot({path:'验证证据/V1.3/production-public-mobile.png',fullPage:true});report.mobileNoOverflow=true;
 const response=await ctx.request.get(report.site+'/raw/68ba435e-1f1d-47d6-b312-a5f2c62058e1.js',{headers:{'Accept-Encoding':'identity'}});assert.equal(response.status(),200);report.raw={status:response.status(),cacheControl:response.headers()['cache-control'],encoding:response.headers()['content-encoding']||'identity',bytes:(await response.body()).length,sha256:createHash('sha256').update(await response.body()).digest('hex')};
 assert.deepEqual(report.errors,[]);report.ok=true;writeFileSync('验证证据/V1.3/browser-production.json',JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
}finally{await browser.close();}
