# Capy/Rex Widgets Hub · V1.4

作者：芜湖。面向 NAS Docker 的组件管理、投稿审核与公开安装页面。

- 公开组件：`/user`，支持名称、文件名、作者、播放器搜索和组合筛选。
- 开发者 / 管理员：`/admin`；管理员模块管理台：`/admin/manage`。
- 在线静态检查：`/checker`，可选文件或粘贴代码。源码留在浏览器，既不上传也不执行。
- Capy 原始脚本：`/raw/<原模块 UUID>.js`；既有 `/api/modules/…` 地址仍可用。
- Capy 图标优先；Rex 图标用于 Rex 安装入口和播放器选项。

部署与兼容性说明见 [V1.4升级说明.md](V1.4升级说明.md)，测试、限制和回退见 [V1.4验收报告.md](V1.4验收报告.md)，低内存浏览器调研见 [V1.3浏览器调研.md](V1.3浏览器调研.md)。初次部署参见 [中文部署说明.md](中文部署说明.md)；涉及版本、检查器、Capy 导入的描述以 V1.4 文档为准。

本发行包不包含 `.env`、生产数据库、账号、登录凭据或私有备份。升级时保留原 `.env` 和 `data/`；不要重新初始化已有数据库。

```sh
docker compose build hub
docker compose up -d --no-deps hub
```

现网：`https://capy.fnzyc.top/user`；在线检查：`https://capy.fnzyc.top/checker`。

历史上游 Cloudflare 功能保留，上游版本独立于 NAS 版本。V1.4 的新页面、`/raw` 和检查器以 NAS Docker 模式为交付目标。

加解密入口 `/crypto` 为外链说明页，具体研究和边界见 V1.4升级说明.md。
